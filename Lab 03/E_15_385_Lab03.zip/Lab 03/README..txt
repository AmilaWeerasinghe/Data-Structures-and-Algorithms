How to  run
compile(1 ,2,3 means there are siz diffrent impplementations of hashing functions)
1.javac HashTableImp(1,2,3,4,5,6).java
2. javac TestHashTable(1,2,3,4,5,6).java

run (1 ,2,3 means there are siz diffrent impplementations of hashing functions)
type bucket follwed by the sie of buckets and the name of the text-file
3. java TestHashTable(1,2,3,4,5,6) bucket 30 sample-text1.txt


COMPLETE REPORT IS PROVIDED